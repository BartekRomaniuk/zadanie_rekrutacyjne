﻿namespace zadanie
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.StworzBaze_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StworzBaze_btn
            // 
            this.StworzBaze_btn.Location = new System.Drawing.Point(63, 41);
            this.StworzBaze_btn.Name = "StworzBaze_btn";
            this.StworzBaze_btn.Size = new System.Drawing.Size(75, 23);
            this.StworzBaze_btn.TabIndex = 0;
            this.StworzBaze_btn.Text = "Stwórz Bazę";
            this.StworzBaze_btn.UseVisualStyleBackColor = true;
            this.StworzBaze_btn.Click += new System.EventHandler(this.StworzBaze_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.StworzBaze_btn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button StworzBaze_btn;
    }
}

