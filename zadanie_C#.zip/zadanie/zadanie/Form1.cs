﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zadanie
{
    public partial class Form1 : Form
    {
        private string _connString = "Host=localhost;User Id=postgres;Password=password;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void StworzBaze_btn_Click(object sender, EventArgs e)
        {
            string sql = @"CREATE DATABASE gisdb
                    WITH
                    OWNER = postgres
                    TEMPLATE = postgis_30_sample
                    ENCODING = 'UTF8'
                    LC_CTYPE = 'Polish_Poland.1250'
                    CONNECTION LIMIT = -1;";
            using (NpgsqlConnection con = new NpgsqlConnection(_connString))
            {
                con.Open();
                NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }

        }
    }
}
